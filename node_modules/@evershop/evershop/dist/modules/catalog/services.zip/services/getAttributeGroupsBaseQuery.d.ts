export function getAttributeGroupsBaseQuery(): import("@evershop/postgres-query-builder").SelectQuery;
