import { SelectQuery } from '@evershop/postgres-query-builder';
export declare const getCategoriesBaseQuery: () => SelectQuery;
