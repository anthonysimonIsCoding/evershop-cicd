export function registerCartItemVariantOptionsField(fields: any): any;
