export function registerCartItemProductUrlField(fields: any): any;
