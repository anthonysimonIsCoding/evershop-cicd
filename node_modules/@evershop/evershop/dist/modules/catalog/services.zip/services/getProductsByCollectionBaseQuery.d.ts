import { SelectQuery } from '@evershop/postgres-query-builder';
export declare const getProductsByCollectionBaseQuery: (collectionId: number) => SelectQuery;
