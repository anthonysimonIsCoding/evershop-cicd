export default function buildUrlReWrite(data: any): Promise<void>;
