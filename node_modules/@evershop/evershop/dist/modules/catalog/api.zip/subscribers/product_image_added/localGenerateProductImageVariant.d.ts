export default function localGenerateProductImageVariant(data: any): Promise<void>;
