export default function deleteUrlReWrite(data: any): Promise<void>;
