import PageHeading from '@components/admin/cms/PageHeading';
import PropTypes from 'prop-types';
import React from 'react';
export default function CategoryEditPageHeading({ backUrl, category }) {
    return (React.createElement(PageHeading, { backUrl: backUrl, heading: category ? `Editing ${category.name}` : 'Create a new category' }));
}
CategoryEditPageHeading.propTypes = {
    backUrl: PropTypes.string.isRequired,
    category: PropTypes.shape({
        name: PropTypes.string
    })
};
CategoryEditPageHeading.defaultProps = {
    category: {}
};
export const layout = {
    areaId: 'content',
    sortOrder: 5
};
export const query = `
  query Query {
    category(id: getContextValue("categoryId", null)) {
      name
    }
    backUrl: url(routeId: "categoryGrid")
  }
`;
//# sourceMappingURL=PageHeading.js.map