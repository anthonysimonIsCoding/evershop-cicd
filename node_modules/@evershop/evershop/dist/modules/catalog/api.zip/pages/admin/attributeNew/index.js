import { setContextValue } from '../../../../graphql/services/contextHelper.js';
export default (request, response) => {
    setContextValue(request, 'pageInfo', {
        title: 'Create a new attribute',
        description: 'Create a new attribute'
    });
};
//# sourceMappingURL=index.js.map