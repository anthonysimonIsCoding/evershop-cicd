import Area from '@components/common/Area';
import { Form } from '@components/common/form/Form';
import PropTypes from 'prop-types';
import React from 'react';
import { toast } from 'react-toastify';
import { get } from '../../../../../lib/util/get.js';
export default function ProductNewForm({ action }) {
    const id = 'productForm';
    return (React.createElement(Form, { method: "POST", action: action, dataFilter: (formData) => {
            if (formData.tax_class === '') {
                formData.tax_class = null;
            }
            return formData;
        }, onError: () => {
            toast.error('Something wrong. Please reload the page!');
        }, onSuccess: (response) => {
            if (response.error) {
                toast.error(get(response, 'error.message', 'Something wrong. Please reload the page!'));
            }
            else {
                toast.success('Product saved successfully!');
                // Wait for 2 seconds to show the success message
                setTimeout(() => {
                    // Redirect to the edit page
                    const editUrl = response.data.links.find((link) => link.rel === 'edit').href;
                    window.location.href = editUrl;
                }, 1500);
            }
        }, submitBtn: false, id: id },
        React.createElement(Area, { id: id, noOuter: true })));
}
ProductNewForm.propTypes = {
    action: PropTypes.string.isRequired
};
export const layout = {
    areaId: 'content',
    sortOrder: 10
};
export const query = `
  query Query {
    action: url(routeId: "createProduct")
    gridUrl: url(routeId: "productGrid")
  }
`;
//# sourceMappingURL=ProductNewForm.js.map