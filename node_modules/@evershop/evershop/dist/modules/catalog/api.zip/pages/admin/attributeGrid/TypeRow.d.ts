declare function TypeRow({ id, areaProps: { row } }: {
    id: any;
    areaProps: {
        row: any;
    };
}): React.JSX.Element;
declare namespace TypeRow {
    namespace propTypes {
        let areaProps: any;
        let id: any;
    }
}
export default TypeRow;
import React from 'react';
