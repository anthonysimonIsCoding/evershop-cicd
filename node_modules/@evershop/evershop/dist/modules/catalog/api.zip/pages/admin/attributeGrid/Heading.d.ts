export default function Heading(): React.JSX.Element;
export namespace layout {
    let areaId: string;
    let sortOrder: number;
}
import React from 'react';
