import { setContextValue } from '../../../../graphql/services/contextHelper.js';
export default (request, response) => {
    setContextValue(request, 'pageInfo', {
        title: 'Create a new product',
        description: 'Create a new product'
    });
};
//# sourceMappingURL=index.js.map