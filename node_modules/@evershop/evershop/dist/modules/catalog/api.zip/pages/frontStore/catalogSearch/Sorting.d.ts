export default function SortingWrapper(): React.JSX.Element;
export namespace layout {
    let areaId: string;
    let sortOrder: number;
}
import React from 'react';
