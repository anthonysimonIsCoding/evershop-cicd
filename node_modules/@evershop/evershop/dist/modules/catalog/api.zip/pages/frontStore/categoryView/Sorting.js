import Sorting from '@components/frontStore/catalog/product/list/Sorting';
import React from 'react';
export default function SortingWrapper() {
    return React.createElement(Sorting, null);
}
export const layout = {
    areaId: 'rightColumn',
    sortOrder: 15
};
//# sourceMappingURL=Sorting.js.map