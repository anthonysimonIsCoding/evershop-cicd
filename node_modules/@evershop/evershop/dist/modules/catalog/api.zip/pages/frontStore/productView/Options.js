import { MultiSelect } from '@components/common/form/fields/MultiSelect';
import { Select } from '@components/common/form/fields/Select';
import PropTypes from 'prop-types';
import React from 'react';
export default function Options({ options = [] }) {
    if (options.length === 0) {
        return null;
    }
    return (React.createElement("div", { className: "product-single-options mt-16 mb-16" },
        React.createElement("div", { className: "product-single-options-title mb-8" },
            React.createElement("strong", null, "Options")),
        options.map((o, i) => {
            const values = o.values.map((v) => ({
                value: v.valueId,
                text: `${v.value} (+ ${v.extraPrice.text})`
            }));
            let FieldComponent = '';
            switch (o.optionType) {
                case 'select':
                    FieldComponent = (React.createElement(Select, { key: i, name: `product_custom_options[${o.optionId}][]`, options: values, validation_rules: parseInt(o.isRequired, 10) === 1 ? ['notEmpty'] : [], formId: "product-form", label: o.optionName }));
                    break;
                case 'multiselect':
                    FieldComponent = (React.createElement(MultiSelect, { key: i, name: `product_custom_options[${o.optionId}][]`, options: values, validation_rules: parseInt(o.isRequired, 10) === 1 ? ['notEmpty'] : [], formId: "product-form", label: o.optionName }));
                    break;
                default:
                    FieldComponent = (React.createElement(Select, { key: i, name: `product_custom_options[${o.optionId}][]`, options: values, validation_rules: parseInt(o.isRequired, 10) === 1 ? ['notEmpty'] : [], formId: "product-form", label: o.optionName }));
            }
            return FieldComponent;
        })));
}
Options.propTypes = {
    options: PropTypes.arrayOf(PropTypes.shape({
        optionId: PropTypes.number,
        isRequired: PropTypes.number,
        optionName: PropTypes.string,
        optionType: PropTypes.string
    }))
};
Options.defaultProps = {
    options: []
};
export const layout = {
    areaId: 'productPageMiddleRight',
    sortOrder: 30
};
export const query = `
  query Query {
    product (id: getContextValue('productId')) {
      options {
        optionId
        isRequired
        optionName
        optionType
        values {
          valueId
          value
          extraPrice {
            value
            text
          }
        }
      }
    }
  }`;
//# sourceMappingURL=Options.js.map