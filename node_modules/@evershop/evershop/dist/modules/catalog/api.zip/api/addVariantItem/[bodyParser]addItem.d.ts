declare function _default(request: any, response: any, next: any): Promise<void>;
export default _default;
