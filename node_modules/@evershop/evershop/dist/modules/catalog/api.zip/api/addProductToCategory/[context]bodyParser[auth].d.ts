declare function _default(request: any, response: any, next: any): void;
export default _default;
