declare function _default(request: any, response: any): Promise<any>;
export default _default;
