declare function _default(request: any, response: any, next: any): Promise<any>;
export default _default;
