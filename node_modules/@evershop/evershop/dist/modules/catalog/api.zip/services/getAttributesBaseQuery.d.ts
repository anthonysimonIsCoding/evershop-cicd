export function getAttributesBaseQuery(): import("@evershop/postgres-query-builder").SelectQuery;
