import type { SelectQuery } from '@evershop/postgres-query-builder';
export declare const getCollectionsBaseQuery: () => SelectQuery;
