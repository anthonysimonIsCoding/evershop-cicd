export default {
    Inventory: {
        qty: (inventory) => inventory.qty || 0
    }
};
//# sourceMappingURL=Inventory.admin.resolvers.js.map