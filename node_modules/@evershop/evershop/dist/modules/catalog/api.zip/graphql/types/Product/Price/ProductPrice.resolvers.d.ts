declare namespace _default {
    namespace Product {
        function price(product: any): {
            regular: number;
            special: number;
        };
    }
}
export default _default;
