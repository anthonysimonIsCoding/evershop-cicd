declare namespace _default {
    namespace Inventory {
        function qty(inventory: any): any;
    }
}
export default _default;
