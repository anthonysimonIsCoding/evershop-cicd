declare namespace _default {
    namespace Product {
        function options(): Promise<never[]>;
    }
}
export default _default;
