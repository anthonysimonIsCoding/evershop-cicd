export default {
    Product: {
        options: async () => [] // TODO: To be implemented
    }
};
//# sourceMappingURL=CustomOption.resolvers.js.map