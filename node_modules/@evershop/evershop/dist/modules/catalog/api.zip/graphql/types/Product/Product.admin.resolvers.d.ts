declare namespace _default {
    namespace Product {
        function editUrl(product: any): string;
        function updateApi(product: any): string;
        function deleteApi(product: any): string;
    }
}
export default _default;
