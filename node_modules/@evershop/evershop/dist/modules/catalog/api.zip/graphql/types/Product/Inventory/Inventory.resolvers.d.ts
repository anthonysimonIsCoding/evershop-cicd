declare namespace _default {
    namespace Product {
        function inventory(product: any): Promise<any>;
    }
}
export default _default;
