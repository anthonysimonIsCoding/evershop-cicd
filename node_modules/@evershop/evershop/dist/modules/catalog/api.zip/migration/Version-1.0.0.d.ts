declare function _default(connection: any): Promise<void>;
export default _default;
