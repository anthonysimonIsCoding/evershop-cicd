declare function _default(): void;
export default _default;
